<footer class="content-info" role="contentinfo">
  <div class="container">
    <?php dynamic_sidebar('sidebar-footer'); ?>

    <div class="">
      <p class="text-center">Copyright © <?php echo date("Y") ?> BodyLogicMD. All Rights Reserved. All Physicians of BodyLogicMD are independent affiliates.</p>
    </div>

  </div>
</footer>

<?php wp_footer(); ?>
